#include <stdio.h>
#include <stdlib.h>

void read_from_file(unsigned char *s1, unsigned char *s2)
{
    FILE *fp = fopen("leak", "r");
    fseek(fp, 0, SEEK_SET);
    fread(s1, 16, 1, fp);
    fread(s2, 16, 1, fp);

    fclose(fp);
}

unsigned char *decrypt(unsigned char *ct_1, unsigned char*ct_2)
{
    //TODO: implement me =)
}

unsigned char *encrypt(unsigned char *pt)
{
    FILE *fp = fopen("key", "r");
    unsigned char *key = malloc(16*sizeof(unsigned char));
    unsigned char *ct = malloc(16*sizeof(unsigned char));
    fread(key, 1, 16, fp);
    
    for(int i = 0; i < 16; i++) {
        ct[i] = pt[i] ^ key[i];
    }
    fclose(fp);
    return ct;
}

int main(void)
{
    unsigned char *pt = "mNih1Ni59GdXT3CD";
    unsigned char *flag = "FOI{REDACTED}";

    FILE *out = fopen("leak", "w");
    unsigned char *ct_1 = encrypt(pt);
    unsigned char *ct_2 = encrypt(flag);
    fwrite(ct_1, 1, 16, out);
    fwrite(ct_2, 1, 16, out);
    free(ct_1);
    free(ct_2);

    fclose(out);

    unsigned char *s1 = calloc(16, sizeof(unsigned char));
    unsigned char *s2 = calloc(16, sizeof(unsigned char));

    read_from_file(s1, s2);
    decrypt(s1, s2);
    free(s1);
    free(s2);
}
