#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void *my_memcpy(void *dst, void *src, size_t n);

void *my_memcpy(void *dst, void *src, size_t n)
{
    size_t len = n;
    while(len--) {
        *(unsigned char *)(dst++) = *(unsigned char *)(src++);
    }
    return dst-len;
}

int main(void)
{
    int x = 112352523;
    int y = 0;

    float z = 0.0;
    float w = 145.234553;

    char *str_1 = "Ciao a tutti!\n";
    char *str_2 = malloc(strlen(str_1));

    printf("%d\n", y);
    printf("%s\n", str_2);
    printf("%0.6f\n", z);

    my_memcpy(&y, &x, sizeof(x));
    my_memcpy(&z, &w, sizeof(w));
    my_memcpy(str_2, str_1, strlen(str_1));

    printf("%d\n", y);
    printf("%s\n", str_2);
    printf("%0.6f\n", z);
    return 0;
}
