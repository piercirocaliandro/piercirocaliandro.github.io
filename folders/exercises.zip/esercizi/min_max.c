#include <stdio.h>

int arr_min(int *arr, int size);
int arr_max(int *arr, int size);

int arr_min(int *arr, int size)
{
    int min = arr[0];
    size -= 1;
    while(size--) {
        if (*arr < min)
            min = *arr;
        arr++;
    }
    return min;
}

int arr_max(int *arr, int size)
{
    int max = -1;
    while(size--) {
        if (*arr > max)
            max = *arr;
        arr++;
    }
    return max;
}

int main(void)
{
    int arr[] = {543643, 76, 234, 564, 675532, 245, 6756464, 5646, 234, 8977, 45, 76, 6, 5353, 547, 8};
    printf("Min: %d\n", arr_min(arr, (int) sizeof(arr)/sizeof(arr[0])));
    printf("Max: %d\n", arr_max(arr, (int) sizeof(arr)/sizeof(arr[0])));
    return 0;
}
