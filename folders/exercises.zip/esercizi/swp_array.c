#include <stdio.h>
#include <stdlib.h>

void print_arr(int arr[], int size);
void print_arr(int *arr, int size);

void swp(int *arr, int size)
{
    for (int i = 0; i <= size/2; i++) {
        int tmp = arr[i];
        arr[i] = arr[size-1-i];
        arr[size-1-i] = tmp;
    }
}

void print_arr(int arr[], int size)
{
    for (int i = 0; i < size; i++)
        printf("%d ", arr[i]);
    puts("\n");
}


int main(void)
{
    int arr_1[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    int arr_2[] = {12, 56, 75, 234, 76, 458, 8756, 123, 64567, 9878};
    int arr_3[] = {5675, 76, 34, 53464, 2345, 654, 70, 123, 54, 65, 235, 767654, 235763};

    print_arr(arr_1, 10);
    print_arr(arr_2, 10);
    print_arr(arr_3, 13);

    swp(arr_1, 10);
    swp(arr_2, 10);
    swp(arr_3, 13);

    print_arr(arr_1, 10);
    print_arr(arr_2, 10);
    print_arr(arr_3, 13);
}
